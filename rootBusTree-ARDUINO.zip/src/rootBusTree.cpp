#inclube "rootBusTree.h"
int wermsg;
void rootBusTree::sendByIndex(int wer, int wermsg){
  pinWrite(wer, 1);
  delay(wermsg);
  pinWrite(wer, 0);
}
int rootBusTree::recv(int wer) {
  wermsg = 0
  while (pinRead(wer)){
  wermsg = wermsg + 1;
  delay(1);
  }
  return wermsg;
}
