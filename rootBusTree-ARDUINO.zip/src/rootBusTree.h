#inclube "Arduino.h"


class rootBusTree {
  void sendByIndex(int wer, String wermsg);
  int recv(int wer);
}
